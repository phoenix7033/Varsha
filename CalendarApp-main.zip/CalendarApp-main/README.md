# CalendarApp
A simple Calendar App developed with Android studio using java

<p float="left" align="middle">
  <img src="https://user-images.githubusercontent.com/74872422/208725107-0f0f67d1-94b3-4edf-923f-f66ce78d5ddc.jpg" width="400" height="900">
  <img src="https://user-images.githubusercontent.com/74872422/208725103-c3f01278-3190-447c-8c7e-01ba4d7554a0.jpg" width="400" height="900">  
</p>
